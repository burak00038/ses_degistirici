import { Feather } from '@expo/vector-icons';
import { Audio } from 'expo-av';
import * as Haptics from 'expo-haptics';
import { StatusBar } from 'expo-status-bar';
import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Alert,
  Animated,
  PanResponder,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { VoiceEngine } from '@/lib/voice-engine';

type IconName = React.ComponentProps<typeof Feather>['name'];

type Effect = {
  id: string;
  label: string;
  icon: IconName;
  tone: string;
  description: string;
};

const EFFECTS: Effect[] = [
  { id: 'deep', label: 'Kalın erkek', icon: 'mic', tone: '#647CFF', description: 'Güçlü ve tok' },
  { id: 'bright', label: 'İnce kadın', icon: 'sun', tone: '#FF83D5', description: 'Parlak ve net' },
  { id: 'child', label: 'Çocuk', icon: 'smile', tone: '#F7C85B', description: 'Enerjik ve neşeli' },
  { id: 'robot', label: 'Robot', icon: 'cpu', tone: '#6EE7F9', description: 'Dijital ve mekanik' },
  { id: 'alien', label: 'Uzaylı', icon: 'radio', tone: '#B88CFF', description: 'Galaksiden sinyal' },
  { id: 'echo', label: 'Yankı', icon: 'repeat', tone: '#68D9B0', description: 'Geniş stereo' },
  { id: 'bass', label: 'Derin ses', icon: 'arrow-down', tone: '#758BFF', description: 'Alt frekans ağırlıklı' },
  { id: 'treble', label: 'Tiz ses', icon: 'arrow-up', tone: '#FF9D65', description: 'Keskin ve canlı' },
  { id: 'monster', label: 'Canavar', icon: 'zap', tone: '#FF667A', description: 'Büyük ve ürkütücü' },
  { id: 'radio', label: 'Radyo', icon: 'rss', tone: '#D0A86D', description: 'Vintage yayın' },
  { id: 'funny', label: 'Komik ses', icon: 'gift', tone: '#E890F6', description: 'Eğlenceli ve farklı' },
  { id: 'custom', label: 'Özel ses', icon: 'sliders', tone: '#A6B5C9', description: 'Kendi preset’in' },
];

const clamp = (value: number) => Math.max(0, Math.min(100, value));

function SliderControl({
  label,
  value,
  suffix,
  icon,
  color,
  onChange,
  testID,
}: {
  label: string;
  value: number;
  suffix?: string;
  icon: IconName;
  color: string;
  onChange: (value: number) => void;
  testID: string;
}) {
  const [trackWidth, setTrackWidth] = useState(0);
  const updateFromX = (x: number) => {
    if (trackWidth > 0) onChange(clamp((x / trackWidth) * 100));
  };

  const responder = useMemo(
    () =>
      PanResponder.create({
        onStartShouldSetPanResponder: () => true,
        onMoveShouldSetPanResponder: () => true,
        onPanResponderGrant: (event) => updateFromX(event.nativeEvent.locationX),
        onPanResponderMove: (event) => updateFromX(event.nativeEvent.locationX),
      }),
    [trackWidth],
  );

  return (
    <View style={styles.sliderRow} testID={testID}>
      <View style={styles.sliderLabelRow}>
        <View style={styles.sliderName}>
          <Feather name={icon} size={14} color={color} />
          <Text style={styles.sliderLabel}>{label}</Text>
        </View>
        <Text style={[styles.sliderValue, { color }]}>
          {Math.round(value)}
          {suffix ?? '%'}
        </Text>
      </View>
      <View
        style={styles.track}
        onLayout={(event) => setTrackWidth(event.nativeEvent.layout.width)}
        {...responder.panHandlers}
      >
        <View style={[styles.trackFill, { width: `${value}%`, backgroundColor: color }]} />
        <View style={[styles.thumb, { left: `${value}%`, borderColor: color, backgroundColor: '#101722' }]} />
      </View>
    </View>
  );
}

function LevelMeter({ level, active }: { level: number; active: boolean }) {
  const bars = useMemo(
    () =>
      Array.from({ length: 30 }, (_, index) => {
        const seed = ((index * 17) % 13) / 13;
        return Math.max(0.18, Math.min(1, level * 1.15 + seed * 0.24));
      }),
    [level],
  );

  return (
    <View style={styles.waveform} accessibilityLabel={`Mikrofon seviyesi ${Math.round(level * 100)} yüzde`}>
      {bars.map((height, index) => (
        <View
          key={index}
          style={[
            styles.waveBar,
            {
              height: 8 + height * 36,
              backgroundColor: active && index < Math.round(level * 30) ? '#6EE7F9' : '#2A384B',
              opacity: active ? 0.65 + height * 0.35 : 0.55,
            },
          ]}
        />
      ))}
    </View>
  );
}

export default function HomeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [selectedEffect, setSelectedEffect] = useState(EFFECTS[3]);
  const [isLive, setIsLive] = useState(false);
  const [isEffectEnabled, setIsEffectEnabled] = useState(true);
  const [inputLevel, setInputLevel] = useState(0.08);
  const [pitch, setPitch] = useState(54);
  const [speed, setSpeed] = useState(50);
  const [echo, setEcho] = useState(12);
  const [reverb, setReverb] = useState(22);
  const [noiseReduction, setNoiseReduction] = useState(68);
  const [strength, setStrength] = useState(74);
  const [previewMode, setPreviewMode] = useState<'effect' | 'original'>('effect');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const engineRef = useRef<VoiceEngine | null>(null);
  const pulse = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, { toValue: 1.04, duration: 1200, useNativeDriver: false }),
        Animated.timing(pulse, { toValue: 1, duration: 1200, useNativeDriver: false }),
      ]),
    ).start();

    return () => {
      pulse.stopAnimation();
      engineRef.current?.stop().catch(() => undefined);
    };
  }, [pulse]);

  const startListening = async () => {
    setErrorMessage(null);
    try {
      const existingPermission = await Audio.getPermissionsAsync();
      if (!existingPermission.granted) {
        const nextPermission = await Audio.requestPermissionsAsync();
        if (!nextPermission.granted) {
          setErrorMessage('Mikrofon izni olmadan canlı dinleme başlatılamaz.');
          return;
        }
      }

      const engine = new VoiceEngine({ onMetering: setInputLevel });
      await engine.start();
      engineRef.current = engine;
      setIsLive(true);
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (error) {
      setIsLive(false);
      setErrorMessage(error instanceof Error ? error.message : 'Ses motoru başlatılamadı.');
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    }
  };

  const stopListening = async () => {
    await engineRef.current?.stop().catch(() => undefined);
    engineRef.current = null;
    setIsLive(false);
    setInputLevel(0.08);
    await Haptics.selectionAsync();
  };

  const toggleLive = () => {
    if (isLive) {
      void stopListening();
    } else {
      void startListening();
    }
  };

  const selectEffect = (effect: Effect) => {
    setSelectedEffect(effect);
    setIsEffectEnabled(true);
    void Haptics.selectionAsync();
  };

  const topInset = insets.top + (Platform.OS === 'web' ? 67 : 12);
  const bottomInset = insets.bottom + (Platform.OS === 'web' ? 34 : 16);

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <StatusBar style="light" />
      <ScrollView
        contentContainerStyle={{ paddingTop: topInset, paddingBottom: bottomInset }}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <View>
            <View style={styles.eyebrowRow}>
              <View style={styles.liveDot} />
              <Text style={styles.eyebrow}>AUDIO LAB / 01</Text>
            </View>
            <Text style={styles.title}>SES DEĞİŞTİRİCİ <Text style={styles.titleAccent}>PRO</Text></Text>
            <Text style={styles.subtitle}>Kulaklığını bağla ve sesini gerçek zamanlı değiştir.</Text>
          </View>
          <Pressable
            accessibilityLabel="Ayarlar"
            testID="settings-button"
            style={({ pressed }) => [styles.iconButton, pressed && styles.pressed]}
            onPress={() => Alert.alert('Ses ayarları', 'Canlı mikrofon izleme ve uygulama içi iletişim için hazır. Telefon görüşmelerinin ses akışı cihazdan cihaza değişebilir.')}
          >
            <Feather name="settings" size={19} color="#B9C6D8" />
          </Pressable>
        </View>

        <Animated.View style={[styles.heroCard, { transform: [{ scale: pulse }] }]}>
          <View style={styles.cardGlow} />
          <View style={styles.heroTopRow}>
            <View style={[styles.effectIcon, { backgroundColor: `${selectedEffect.tone}20` }]}>
              <Feather name={selectedEffect.icon} size={25} color={selectedEffect.tone} />
            </View>
            <View style={styles.heroMeta}>
              <Text style={styles.cardKicker}>ŞU AN SEÇİLİ</Text>
              <Text style={styles.heroEffectName}>{selectedEffect.label}</Text>
              <Text style={styles.heroDescription}>{selectedEffect.description}</Text>
            </View>
            <View style={styles.livePill}>
              <View style={[styles.liveDotSmall, { backgroundColor: isLive ? '#6EE7F9' : '#627084' }]} />
              <Text style={styles.livePillText}>{isLive ? 'CANLI' : 'HAZIR'}</Text>
            </View>
          </View>
          <LevelMeter level={inputLevel} active={isLive} />
          <View style={styles.meterFooter}>
            <View style={styles.meterLabel}>
              <Feather name="mic" size={13} color="#8D9AAF" />
              <Text style={styles.meterText}>Giriş seviyesi</Text>
            </View>
            <Text style={styles.meterNumber}>{Math.round(inputLevel * 100)}%</Text>
          </View>
        </Animated.View>

        <View style={styles.connectionRow}>
          <View style={styles.connectionItem}>
            <View style={[styles.connectionIcon, { backgroundColor: '#163B42' }]}>
              <Feather name="mic" size={16} color="#6EE7F9" />
            </View>
            <View>
              <Text style={styles.connectionLabel}>Mikrofon</Text>
              <Text style={styles.connectionValue}>{isLive ? 'Aktif ve dinleniyor' : 'Başlatılmayı bekliyor'}</Text>
            </View>
          </View>
          <View style={styles.connectionDivider} />
          <View style={styles.connectionItem}>
            <View style={[styles.connectionIcon, { backgroundColor: '#252040' }]}>
              <Feather name="headphones" size={16} color="#B88CFF" />
            </View>
            <View>
              <Text style={styles.connectionLabel}>Kulaklık</Text>
              <Text style={styles.connectionValue}>Bluetooth / kablolu</Text>
            </View>
          </View>
        </View>

        {errorMessage ? (
          <Pressable style={styles.errorBanner} onPress={() => setErrorMessage(null)} accessibilityLabel="Hata mesajını kapat">
            <Feather name="alert-circle" size={17} color="#FF9AA8" />
            <Text style={styles.errorText}>{errorMessage}</Text>
            <Feather name="x" size={16} color="#FF9AA8" />
          </Pressable>
        ) : null}

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Ses efektleri</Text>
          <Text style={styles.sectionHint}>{EFFECTS.length} preset</Text>
        </View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.effectList}>
          {EFFECTS.map((effect) => {
            const isSelected = selectedEffect.id === effect.id;
            return (
              <Pressable
                key={effect.id}
                accessibilityLabel={`${effect.label} efektini seç`}
                testID={`effect-${effect.id}`}
                onPress={() => selectEffect(effect)}
                style={({ pressed }) => [
                  styles.effectChip,
                  isSelected && { borderColor: effect.tone, backgroundColor: `${effect.tone}16` },
                  pressed && styles.pressed,
                ]}
              >
                <View style={[styles.chipIcon, { backgroundColor: `${effect.tone}18` }]}>
                  <Feather name={effect.icon} size={15} color={effect.tone} />
                </View>
                <Text style={[styles.effectChipText, isSelected && { color: '#F3F7FF' }]}>{effect.label}</Text>
                {isSelected ? <View style={[styles.selectedMark, { backgroundColor: effect.tone }]} /> : null}
              </Pressable>
            );
          })}
        </ScrollView>

        <View style={styles.controlHeader}>
          <Text style={styles.sectionTitle}>Kontroller</Text>
          <View style={styles.previewToggle}>
            <Pressable
              testID="preview-original"
              onPress={() => setPreviewMode('original')}
              style={[styles.previewOption, previewMode === 'original' && styles.previewOptionActive]}
            >
              <Text style={[styles.previewText, previewMode === 'original' && styles.previewTextActive]}>Orijinal</Text>
            </Pressable>
            <Pressable
              testID="preview-effected"
              onPress={() => setPreviewMode('effect')}
              style={[styles.previewOption, previewMode === 'effect' && styles.previewOptionActive]}
            >
              <Text style={[styles.previewText, previewMode === 'effect' && styles.previewTextActive]}>Efektli</Text>
            </Pressable>
          </View>
        </View>

        <View style={styles.controlsCard}>
          <View style={styles.primaryControlRow}>
            <View style={styles.primaryControlCopy}>
              <Text style={styles.controlTitle}>Efekt yoğunluğu</Text>
              <Text style={styles.controlSubtitle}>{previewMode === 'effect' ? `${selectedEffect.label} önizlemesi` : 'Mikrofon sinyali'}</Text>
            </View>
            <Pressable
              testID="effect-toggle"
              accessibilityLabel={isEffectEnabled ? 'Efekti kapat' : 'Efekti aç'}
              onPress={() => setIsEffectEnabled((value) => !value)}
              style={({ pressed }) => [
                styles.effectToggle,
                { backgroundColor: isEffectEnabled ? '#6EE7F9' : '#273344' },
                pressed && styles.pressed,
              ]}
            >
              <Feather name={isEffectEnabled ? 'zap' : 'slash'} size={19} color={isEffectEnabled ? '#071016' : '#91A0B4'} />
              <Text style={[styles.effectToggleText, { color: isEffectEnabled ? '#071016' : '#91A0B4' }]}>
                {isEffectEnabled ? 'AÇIK' : 'KAPALI'}
              </Text>
            </Pressable>
          </View>
          <SliderControl label="Efekt gücü" value={strength} icon="zap" color="#6EE7F9" onChange={setStrength} testID="slider-strength" />
          <SliderControl label="Ses perdesi" value={pitch} suffix=" st" icon="sliders" color="#B88CFF" onChange={setPitch} testID="slider-pitch" />
          <SliderControl label="Ses hızı" value={speed} icon="fast-forward" color="#FFB86B" onChange={setSpeed} testID="slider-speed" />
          <SliderControl label="Yankı" value={echo} icon="repeat" color="#68D9B0" onChange={setEcho} testID="slider-echo" />
          <SliderControl label="Reverb" value={reverb} icon="maximize-2" color="#FF83D5" onChange={setReverb} testID="slider-reverb" />
          <SliderControl label="Gürültü azaltma" value={noiseReduction} icon="wind" color="#A6B5C9" onChange={setNoiseReduction} testID="slider-noise" />
        </View>

        <View style={styles.safeNotice}>
          <Feather name="shield" size={16} color="#8FA2BC" />
          <Text style={styles.safeNoticeText}>
            Uygulama içi canlı izleme ve VoIP senaryoları için tasarlandı. Normal telefon görüşmelerinin ses akışı Android tarafından cihaz bazında sınırlandırılabilir.
          </Text>
        </View>

        <Pressable
          testID="live-toggle"
          accessibilityLabel={isLive ? 'Canlı dinlemeyi durdur' : 'Canlı dinlemeyi başlat'}
          onPress={toggleLive}
          style={({ pressed }) => [styles.liveButton, isLive && styles.liveButtonActive, pressed && styles.pressed]}
        >
          <View style={[styles.liveButtonIcon, isLive && styles.liveButtonIconActive]}>
            <Feather name={isLive ? 'square' : 'play'} size={18} color={isLive ? '#FF667A' : '#071016'} />
          </View>
          <View>
            <Text style={[styles.liveButtonTitle, isLive && { color: '#F3F7FF' }]}>
              {isLive ? 'CANLI DİNLEMEYİ DURDUR' : 'CANLI DİNLEMEYİ BAŞLAT'}
            </Text>
            <Text style={styles.liveButtonSubtitle}>{isLive ? 'Mikrofon sinyali işleniyor' : 'Mikrofon izni istenecek'}</Text>
          </View>
          <Feather name="arrow-up-right" size={19} color={isLive ? '#FF9AA8' : '#6EE7F9'} />
        </Pressable>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  header: {
    paddingHorizontal: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 22,
  },
  eyebrowRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 9 },
  liveDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: '#6EE7F9' },
  eyebrow: { color: '#6EE7F9', fontSize: 10, fontWeight: '700', letterSpacing: 2 },
  title: { color: '#F3F7FF', fontSize: 26, lineHeight: 32, fontWeight: '700', letterSpacing: -0.6 },
  titleAccent: { color: '#6EE7F9' },
  subtitle: { color: '#8D9AAF', fontSize: 13, marginTop: 6, letterSpacing: 0.1 },
  iconButton: { width: 42, height: 42, borderRadius: 14, backgroundColor: '#111722', borderWidth: 1, borderColor: '#263142', alignItems: 'center', justifyContent: 'center' },
  pressed: { opacity: 0.72, transform: [{ scale: 0.98 }] },
  heroCard: { marginHorizontal: 20, backgroundColor: '#111722', borderRadius: 24, borderWidth: 1, borderColor: '#263142', padding: 18, overflow: 'hidden' },
  cardGlow: { position: 'absolute', width: 180, height: 180, borderRadius: 90, right: -75, top: -95, backgroundColor: '#1B3645', opacity: 0.6 },
  heroTopRow: { flexDirection: 'row', alignItems: 'center' },
  effectIcon: { width: 58, height: 58, borderRadius: 18, alignItems: 'center', justifyContent: 'center' },
  heroMeta: { flex: 1, marginLeft: 14 },
  cardKicker: { color: '#7E8CA0', fontSize: 9, fontWeight: '700', letterSpacing: 1.6 },
  heroEffectName: { color: '#F3F7FF', fontSize: 20, fontWeight: '700', marginTop: 2 },
  heroDescription: { color: '#8D9AAF', fontSize: 12, marginTop: 2 },
  livePill: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: '#0C121B', borderRadius: 20, paddingHorizontal: 9, paddingVertical: 7 },
  liveDotSmall: { width: 6, height: 6, borderRadius: 3 },
  livePillText: { color: '#9BACBF', fontSize: 9, fontWeight: '700', letterSpacing: 1 },
  waveform: { height: 54, marginTop: 22, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 3 },
  waveBar: { flex: 1, minWidth: 2, maxWidth: 7, borderRadius: 4 },
  meterFooter: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 12 },
  meterLabel: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  meterText: { color: '#8D9AAF', fontSize: 11 },
  meterNumber: { color: '#6EE7F9', fontWeight: '700', fontSize: 12 },
  connectionRow: { marginHorizontal: 20, marginTop: 13, backgroundColor: '#0D131D', borderRadius: 16, borderWidth: 1, borderColor: '#1B2635', padding: 12, flexDirection: 'row', alignItems: 'center' },
  connectionItem: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 9 },
  connectionIcon: { width: 32, height: 32, borderRadius: 10, justifyContent: 'center', alignItems: 'center' },
  connectionLabel: { color: '#F3F7FF', fontSize: 11, fontWeight: '600' },
  connectionValue: { color: '#748398', fontSize: 9, marginTop: 2 },
  connectionDivider: { width: 1, height: 27, backgroundColor: '#263142', marginHorizontal: 7 },
  errorBanner: { marginHorizontal: 20, marginTop: 12, padding: 12, borderRadius: 14, backgroundColor: '#321C28', borderWidth: 1, borderColor: '#693040', flexDirection: 'row', alignItems: 'center', gap: 9 },
  errorText: { color: '#FFB6C0', flex: 1, fontSize: 11, lineHeight: 16 },
  sectionHeader: { paddingHorizontal: 20, marginTop: 25, flexDirection: 'row', alignItems: 'baseline', justifyContent: 'space-between' },
  sectionTitle: { color: '#F3F7FF', fontSize: 16, fontWeight: '700', letterSpacing: -0.2 },
  sectionHint: { color: '#6D7D91', fontSize: 10, letterSpacing: 0.8 },
  effectList: { paddingHorizontal: 20, paddingTop: 12, paddingBottom: 2, gap: 8 },
  effectChip: { minWidth: 92, height: 83, borderRadius: 16, backgroundColor: '#101722', borderWidth: 1, borderColor: '#202C3B', paddingHorizontal: 11, paddingVertical: 10, justifyContent: 'space-between' },
  chipIcon: { width: 28, height: 28, borderRadius: 9, alignItems: 'center', justifyContent: 'center' },
  effectChipText: { color: '#95A2B4', fontSize: 11, fontWeight: '600', maxWidth: 83 },
  selectedMark: { position: 'absolute', top: 8, right: 8, width: 5, height: 5, borderRadius: 3 },
  controlHeader: { paddingHorizontal: 20, marginTop: 27, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  previewToggle: { flexDirection: 'row', backgroundColor: '#111722', borderRadius: 11, padding: 3, borderWidth: 1, borderColor: '#263142' },
  previewOption: { paddingHorizontal: 9, paddingVertical: 6, borderRadius: 8 },
  previewOptionActive: { backgroundColor: '#263142' },
  previewText: { color: '#76859A', fontSize: 10, fontWeight: '600' },
  previewTextActive: { color: '#F3F7FF' },
  controlsCard: { marginHorizontal: 20, marginTop: 12, backgroundColor: '#111722', borderRadius: 20, padding: 16, borderWidth: 1, borderColor: '#263142' },
  primaryControlRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 18 },
  primaryControlCopy: { flex: 1 },
  controlTitle: { color: '#F3F7FF', fontSize: 13, fontWeight: '700' },
  controlSubtitle: { color: '#7F8FA4', fontSize: 10, marginTop: 3 },
  effectToggle: { minWidth: 82, borderRadius: 12, paddingVertical: 10, paddingHorizontal: 12, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 6 },
  effectToggleText: { fontSize: 10, fontWeight: '800', letterSpacing: 0.7 },
  sliderRow: { marginBottom: 17 },
  sliderLabelRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 9 },
  sliderName: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  sliderLabel: { color: '#AAB7C8', fontSize: 11, fontWeight: '600' },
  sliderValue: { fontSize: 11, fontWeight: '700' },
  trackFill: { position: 'absolute', left: 0, top: 8, height: 4, borderRadius: 3 },
  track: { height: 20, justifyContent: 'center', backgroundColor: '#273344', borderRadius: 5 },
  thumb: { position: 'absolute', top: 3, width: 14, height: 14, marginLeft: -7, borderRadius: 7, borderWidth: 3 },
  safeNotice: { marginHorizontal: 20, marginTop: 14, padding: 12, borderRadius: 14, backgroundColor: '#0D131D', flexDirection: 'row', gap: 9, alignItems: 'flex-start' },
  safeNoticeText: { color: '#7E8EA3', flex: 1, fontSize: 10, lineHeight: 15 },
  liveButton: { marginHorizontal: 20, marginTop: 15, borderRadius: 18, padding: 14, backgroundColor: '#6EE7F9', flexDirection: 'row', alignItems: 'center', gap: 11 },
  liveButtonActive: { backgroundColor: '#1C202C', borderWidth: 1, borderColor: '#633340' },
  liveButtonIcon: { width: 37, height: 37, borderRadius: 12, backgroundColor: '#D8FBFF', alignItems: 'center', justifyContent: 'center' },
  liveButtonIconActive: { backgroundColor: '#321C28' },
  liveButtonTitle: { color: '#071016', fontSize: 11, fontWeight: '800', letterSpacing: 0.7 },
  liveButtonSubtitle: { color: '#7C8B9F', fontSize: 10, marginTop: 3 },
});