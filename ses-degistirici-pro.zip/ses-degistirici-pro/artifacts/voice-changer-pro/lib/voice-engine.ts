import { Audio } from 'expo-av';

export type MeteringListener = (level: number) => void;

export type VoiceEngineOptions = {
  onMetering: MeteringListener;
};

/**
 * Keeps the low-latency audio boundary separate from the screen.
 *
 * Expo's managed runtime can capture the microphone and expose metering, but
 * cannot insert an arbitrary native DSP graph into another app's phone call.
 * This engine intentionally targets in-app monitoring/VoIP and leaves the
 * effect graph as a replaceable boundary for a future Android native module.
 */
export class VoiceEngine {
  private recording: Audio.Recording | null = null;
  private readonly onMetering: MeteringListener;

  constructor({ onMetering }: VoiceEngineOptions) {
    this.onMetering = onMetering;
  }

  async start(): Promise<void> {
    const permission = await Audio.requestPermissionsAsync();
    if (!permission.granted) {
      throw new Error('Mikrofon izni verilmedi.');
    }

    await Audio.setAudioModeAsync({
      allowsRecordingIOS: true,
      playsInSilentModeIOS: true,
      staysActiveInBackground: true,
      shouldDuckAndroid: false,
      playThroughEarpieceAndroid: false,
    });

    const { recording } = await Audio.Recording.createAsync(
      {
        ...Audio.RecordingOptionsPresets.LOW_QUALITY,
        isMeteringEnabled: true,
      },
      (status) => {
        if (!status.isRecording) return;
        const metering = typeof status.metering === 'number' ? status.metering : -60;
        const normalized = Math.max(0.04, Math.min(1, (metering + 60) / 60));
        this.onMetering(normalized);
      },
      80,
    );

    this.recording = recording;
  }

  async stop(): Promise<void> {
    const current = this.recording;
    this.recording = null;
    if (!current) return;

    current.setOnRecordingStatusUpdate(null);
    await current.stopAndUnloadAsync();
    await Audio.setAudioModeAsync({
      allowsRecordingIOS: false,
      playsInSilentModeIOS: true,
      staysActiveInBackground: false,
      shouldDuckAndroid: true,
    });
  }
}