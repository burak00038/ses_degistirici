# Ses Değiştirici PRO

Android odaklı Expo mobil uygulaması.

## Kurulum

```bash
pnpm install
pnpm --filter @workspace/voice-changer-pro run dev
```

Uygulamayı Expo Go ile QR kod üzerinden açabilirsiniz.

## İçerik

- Gerçek mikrofon izni ve giriş seviyesi ölçümü
- 12 ses efekti preset'i
- Pitch, speed, echo, reverb, gürültü azaltma ve efekt gücü kontrolleri
- Bluetooth/kablolu kulaklık durum arayüzü
- Koyu tema ve Android mikrofon izinleri

Not: Android normal telefon görüşmelerinin ses akışını her cihazda doğrudan değiştirmeye izin vermeyebilir. Uygulama içi izleme ve VoIP destekli senaryolara odaklanır.
